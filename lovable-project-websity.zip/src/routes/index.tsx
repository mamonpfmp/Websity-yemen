import { createFileRoute } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useState, useEffect } from "react";
import {
  Sparkles, Clock, ShieldCheck, Star, Zap, Smartphone, Search, Palette,
  HeadphonesIcon, RefreshCw, ShoppingCart, Menu, X, Globe, ArrowLeft, Check,
  Store, Briefcase, UtensilsCrossed, Calendar, Image as ImageIcon, Dumbbell,
  Mail, Phone, User, ExternalLink,
} from "lucide-react";
import { toast } from "sonner";
import {
  Accordion, AccordionContent, AccordionItem, AccordionTrigger,
} from "@/components/ui/accordion";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { getServices, getReviews, submitReview, submitLead } from "@/lib/site.functions";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Websity-Yemen — متجرك الإلكتروني جاهز خلال 24 ساعة" },
      { name: "description", content: "نصمم ونطوّر وننشر متجرك أو موقعك الاحترافي في 24 ساعة فقط. تصميم بريميوم محسّن للبيع، تسليم سريع، ودعم حقيقي." },
      { property: "og:title", content: "Websity-Yemen — متجرك الإلكتروني جاهز خلال 24 ساعة" },
      { property: "og:description", content: "نصمم ونطوّر وننشر مشروعك الكامل في وقت قياسي." },
      { property: "og:url", content: "/" },
    ],
    links: [{ rel: "canonical", href: "/" }],
  }),
  component: HomePage,
});

function HomePage() {
  return (
    <div className="min-h-screen bg-background text-foreground">
      <Header />
      <main>
        <Hero />
        <Services />
        <Audiences />
        <Process />
        <Features />
        <Templates />
        <Clients />
        <Tech />
        <Reviews />
        <FAQ />
        <Contact />
      </main>
      <Footer />
      <CookieBanner />
    </div>
  );
}

/* =================== HEADER =================== */
function Header() {
  const [open, setOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 20);
    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, []);
  const links = [
    { href: "#services", label: "الخدمات" },
    { href: "#process", label: "آلية العمل" },
    { href: "#clients", label: "أعمالنا" },
    { href: "#why-us", label: "لماذا نحن" },
    { href: "#faq", label: "الأسئلة" },
  ];
  return (
    <header className={`fixed top-0 inset-x-0 z-50 transition-all ${scrolled ? "bg-background/80 backdrop-blur-xl border-b border-border" : ""}`}>
      <div className="container mx-auto flex items-center justify-between px-4 py-4">
        <a href="#top" className="flex items-center gap-2 font-display text-xl font-extrabold">
          <span className="grid place-items-center size-9 rounded-xl bg-gradient-neon glow-cyan">
            <Zap className="size-5 text-background" strokeWidth={2.5} />
          </span>
          <span>Websity<span className="text-gradient">-Yemen</span></span>
        </a>
        <nav className="hidden md:flex items-center gap-8 text-sm font-medium">
          {links.map(l => (
            <a key={l.href} href={l.href} className="text-muted-foreground hover:text-foreground transition">{l.label}</a>
          ))}
        </nav>
        <div className="flex items-center gap-3">
          <button className="hidden md:flex items-center gap-1.5 text-sm text-muted-foreground hover:text-foreground transition">
            <Globe className="size-4" /> AR
          </button>
          <a href="#contact" className="hidden sm:inline-flex items-center gap-1.5 rounded-full bg-gradient-neon px-4 py-2 text-sm font-bold text-background glow-cyan">
            ابدأ الآن
          </a>
          <button className="relative grid place-items-center size-10 rounded-full glass-card" aria-label="السلة">
            <ShoppingCart className="size-4" />
          </button>
          <button onClick={() => setOpen(!open)} className="md:hidden grid place-items-center size-10 rounded-full glass-card" aria-label="القائمة">
            {open ? <X className="size-4" /> : <Menu className="size-4" />}
          </button>
        </div>
      </div>
      {open && (
        <div className="md:hidden glass-card border-t border-border">
          <nav className="container mx-auto px-4 py-4 flex flex-col gap-3">
            {links.map(l => (
              <a key={l.href} href={l.href} onClick={() => setOpen(false)} className="py-2 text-sm">{l.label}</a>
            ))}
          </nav>
        </div>
      )}
    </header>
  );
}

/* =================== HERO =================== */
function Hero() {
  return (
    <section id="top" className="relative pt-32 pb-20 md:pt-40 md:pb-28">
      <div className="container mx-auto px-4 text-center">
        <div className="inline-flex items-center gap-2 rounded-full border border-neon-cyan/40 bg-neon-cyan/5 px-4 py-1.5 text-xs md:text-sm text-neon-cyan">
          <Sparkles className="size-3.5" />
          تسليم مضمون خلال 24 ساعة
        </div>
        <h1 className="mt-6 font-display text-4xl md:text-7xl font-extrabold leading-tight tracking-tight">
          متجرك الإلكتروني أو موقعك<br />الاحترافي <span className="text-gradient">جاهز خلال 24 ساعة</span>
        </h1>
        <p className="mt-6 mx-auto max-w-2xl text-base md:text-lg text-muted-foreground leading-relaxed">
          نصمم، نطوّر، وننشر مشروعك الكامل في وقت قياسي. تصميم بريميوم محسّن للبيع، فكل ما عليك هو استقبال طلباتك.
        </p>
        <div className="mt-8 flex flex-wrap items-center justify-center gap-3">
          <a href="#services" className="group inline-flex items-center gap-2 rounded-full bg-gradient-neon px-6 py-3 font-bold text-background glow-cyan transition hover:scale-105">
            استعرض الباقات
            <ArrowLeft className="size-4 transition group-hover:-translate-x-1" />
          </a>
          <a href="#process" className="inline-flex items-center gap-2 rounded-full border border-border bg-card/50 px-6 py-3 font-medium">
            كيف نعمل
          </a>
        </div>
        <div className="mt-14 grid grid-cols-1 md:grid-cols-3 gap-4 max-w-4xl mx-auto">
          {[
            { icon: Clock, title: "تسليم خلال 24 ساعة", sub: "بدون انتظار" },
            { icon: ShieldCheck, title: "ضمان الرضا", sub: "نعدّل حتى تحبه" },
            { icon: Sparkles, title: "تصميم بريميوم", sub: "فريد واحترافي" },
          ].map((f) => (
            <div key={f.title} className="glass-card rounded-2xl p-5 text-start flex items-center gap-4">
              <div className="grid place-items-center size-11 rounded-xl bg-neon-cyan/10 text-neon-cyan">
                <f.icon className="size-5" />
              </div>
              <div>
                <div className="font-bold">{f.title}</div>
                <div className="text-sm text-muted-foreground">{f.sub}</div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

/* =================== SERVICES =================== */
function Services() {
  const fn = useServerFn(getServices);
  const { data, isLoading, error } = useQuery({ queryKey: ["services"], queryFn: () => fn() });

  return (
    <section id="services" className="py-20 md:py-28">
      <div className="container mx-auto px-4">
        <SectionHeader eyebrow="خدماتنا" title={<>اختر الباقة <span className="text-gradient">المثالية لمشروعك</span></>}
          subtitle="كل باقة تشمل التصميم، التطوير، إعداد النطاق، والتسليم خلال 24 ساعة." />
        <div className="mt-12 grid gap-6 md:grid-cols-3">
          {isLoading && Array.from({ length: 3 }).map((_, i) => (
            <div key={i} className="glass-card rounded-3xl p-8 h-96 animate-pulse" />
          ))}
          {error && <p className="text-center col-span-full text-destructive">تعذّر تحميل الخدمات.</p>}
          {data?.map((s) => (
            <div key={s.id} className={`relative glass-card rounded-3xl p-8 flex flex-col ${s.highlighted ? "border-neon-cyan/50 glow-cyan" : ""}`}>
              {s.highlighted && (
                <div className="absolute -top-3 right-6 rounded-full bg-gradient-neon px-3 py-1 text-xs font-bold text-background">
                  الأكثر طلباً
                </div>
              )}
              <h3 className="font-display text-2xl font-bold">{s.name}</h3>
              {s.tagline && <p className="text-sm text-muted-foreground mt-1">{s.tagline}</p>}
              <div className="mt-6 font-display text-4xl font-extrabold text-gradient">{s.price}</div>
              <ul className="mt-6 space-y-3 flex-1">
                {(s.features as string[]).map((f, i) => (
                  <li key={i} className="flex items-start gap-2 text-sm">
                    <Check className="size-4 mt-0.5 text-neon-cyan flex-shrink-0" />
                    <span>{f}</span>
                  </li>
                ))}
              </ul>
              <a href="#contact" className={`mt-8 inline-flex items-center justify-center rounded-full py-3 font-bold transition ${s.highlighted ? "bg-gradient-neon text-background glow-cyan" : "border border-border bg-card"}`}>
                اطلب الآن
              </a>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

/* =================== AUDIENCES =================== */
function Audiences() {
  const items = [
    { icon: User, title: "المستقلون", desc: "محترفون يحتاجون موقعاً بسيطاً لجذب العملاء وبناء صورتهم." },
    { icon: Store, title: "الأعمال المحلية", desc: "مقاهي، صالونات، ورش... بحضور إلكتروني وحجوزات سهلة." },
    { icon: Briefcase, title: "المتاجر الفعلية", desc: "محلات تريد عرض كتالوجها وجذب مزيد من الزوار." },
    { icon: ShoppingCart, title: "علامات جاهزة للبيع أونلاين", desc: "علامات مستعدة للقفزة نحو التجارة الإلكترونية." },
  ];
  return (
    <section className="py-20 md:py-28 bg-card/30">
      <div className="container mx-auto px-4">
        <SectionHeader eyebrow="لمن نصمم" title={<>نصمم <span className="text-gradient">لنوع نشاطك</span></>}
          subtitle="مهما كان مجالك، ننشئ الموقع المثالي ليبرز ويحقق نتائج." />
        <div className="mt-12 grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
          {items.map((it) => (
            <div key={it.title} className="group glass-card rounded-2xl p-6 transition hover:border-neon-purple/50 hover:-translate-y-1">
              <div className="grid place-items-center size-12 rounded-xl bg-gradient-neon-soft text-neon-purple mb-4 group-hover:scale-110 transition">
                <it.icon className="size-5" />
              </div>
              <h3 className="font-bold text-lg">{it.title}</h3>
              <p className="text-sm text-muted-foreground mt-2 leading-relaxed">{it.desc}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

/* =================== PROCESS =================== */
function Process() {
  const steps = [
    { n: 1, title: "أخبرنا بفكرتك", desc: "نتحاور معك لفهم نشاطك وأسلوبك وأهدافك." },
    { n: 2, title: "نصمم موقعك", desc: "نبتكر تصميماً فريداً بريميوم 100% مخصصاً لعلامتك." },
    { n: 3, title: "تطوير سريع", desc: "نبرمج ونعدّ كل شيء: النطاق، الدفع، SEO، والسرعة." },
    { n: 4, title: "تسليم خلال 24 ساعة", desc: "تستلم مشروعك جاهزاً للبيع. الدعم متضمَّن." },
  ];
  return (
    <section id="process" className="py-20 md:py-28">
      <div className="container mx-auto px-4">
        <SectionHeader eyebrow="كيف نعمل" title={<>من الفكرة إلى الإنترنت <span className="text-gradient">في 4 خطوات</span></>} />
        <div className="mt-14 grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
          {steps.map((s) => (
            <div key={s.n} className="relative glass-card rounded-2xl p-6">
              <div className="font-display text-6xl font-black text-gradient leading-none opacity-60">{s.n}</div>
              <h3 className="mt-4 font-bold text-lg">{s.title}</h3>
              <p className="text-sm text-muted-foreground mt-2 leading-relaxed">{s.desc}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

/* =================== FEATURES =================== */
function Features() {
  const items = [
    { icon: Zap, title: "كود نظيف وسريع", desc: "مواقع مُحسَّنة بأوقات تحميل أقل من ثانية." },
    { icon: Smartphone, title: "متجاوب 100%", desc: "يظهر بشكل مثالي على الجوال واللوحي وسطح المكتب." },
    { icon: Search, title: "SEO من اليوم الأول", desc: "بنية محسَّنة ليجدك جوجل بسهولة." },
    { icon: Palette, title: "تصميم بريميوم", desc: "جماليات حديثة واحترافية فريدة لعلامتك." },
    { icon: HeadphonesIcon, title: "دعم حقيقي", desc: "نرد بسرعة ونبقى معك بعد التسليم." },
    { icon: RefreshCw, title: "تعديلات متضمَّنة", desc: "تعديلات غير محدودة خلال الأسبوع الأول." },
  ];
  return (
    <section id="why-us" className="py-20 md:py-28 bg-card/30">
      <div className="container mx-auto px-4">
        <SectionHeader eyebrow="لماذا نحن" title={<>نتائج احترافية <span className="text-gradient">بدون أي عناء</span></>} />
        <div className="mt-12 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {items.map((it) => (
            <div key={it.title} className="glass-card rounded-2xl p-6">
              <div className="grid place-items-center size-12 rounded-xl bg-gradient-neon-soft text-neon-cyan mb-4">
                <it.icon className="size-5" />
              </div>
              <h3 className="font-bold text-lg">{it.title}</h3>
              <p className="text-sm text-muted-foreground mt-2 leading-relaxed">{it.desc}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

/* =================== TEMPLATES =================== */
function Templates() {
  const cats = [
    { icon: ShoppingCart, title: "المتاجر الإلكترونية", desc: "كتالوج كامل، سلة، بوابة دفع، وإدارة طلبات." },
    { icon: Briefcase, title: "مواقع الشركات", desc: "صورة احترافية للشركات والأعمال B2B." },
    { icon: UtensilsCrossed, title: "المطاعم والضيافة", desc: "قائمة رقمية، حجوزات أونلاين، وطلبات توصيل." },
    { icon: Calendar, title: "الخدمات والحجوزات", desc: "حجز مواعيد مدمج وتذكيرات تلقائية." },
    { icon: ImageIcon, title: "بورتفوليو إبداعي", desc: "اعرض أعمالك بمعارض بصرية مذهلة." },
    { icon: Dumbbell, title: "النوادي والمدرّبون", desc: "حجز حصص، خطط تدريب، ودفع أونلاين." },
  ];
  return (
    <section className="py-20 md:py-28">
      <div className="container mx-auto px-4">
        <SectionHeader eyebrow="قوالب وأمثلة" title={<>شاهد كيف <span className="text-gradient">نصمم المواقع</span></>}
          subtitle="استعرض كل فئة لترى أمثلة على المشاريع التي يمكننا إنشاؤها لك." />
        <div className="mt-12 max-w-3xl mx-auto">
          <Accordion type="single" collapsible className="space-y-3">
            {cats.map((c, i) => (
              <AccordionItem key={i} value={`item-${i}`} className="glass-card rounded-2xl border-0 px-5">
                <AccordionTrigger className="hover:no-underline py-5">
                  <div className="flex items-center gap-3 text-start">
                    <div className="grid place-items-center size-10 rounded-lg bg-gradient-neon-soft text-neon-cyan">
                      <c.icon className="size-5" />
                    </div>
                    <span className="font-bold">{c.title}</span>
                  </div>
                </AccordionTrigger>
                <AccordionContent className="text-muted-foreground pb-5">
                  {c.desc}
                </AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        </div>
      </div>
    </section>
  );
}

/* =================== CLIENTS =================== */
function Clients() {
  const projects = [
    {
      category: "متجر إلكتروني",
      icon: ShoppingCart,
      name: "ميرا شوب | Mira Shop",
      desc: "متجر مستحضرات تجميل أصلية — عناية بالبشرة، مكياج وعطور بأسعار مميزة.",
      url: "https://mirashop.mamonpfmp.workers.dev/",
    },
    {
      category: "متجر إلكتروني",
      icon: ShoppingCart,
      name: "متجر ميرا — Shopify",
      desc: "مستحضرات التجميل والعناية بالبشرة والعطور والحقائب والإكسسوارات.",
      url: "https://mira-shopify.mamonpfmp.workers.dev/",
    },
    {
      category: "متجر إلكتروني",
      icon: ShoppingCart,
      name: "HTH ONLINE",
      desc: "متجر ساعات أصلية — ساعات رجالية ونسائية من أشهر الماركات العالمية.",
      url: "https://hth-online.mamonpfmp.workers.dev/",
    },
    {
      category: "خدمات وحجوزات",
      icon: Calendar,
      name: "وَصَّال كوم",
      desc: "منصة يمنية للتسويق الرقمي — SEO، سوشيال ميديا، إعلانات، واستشارات.",
      url: "https://wassal.mamonpfmp.workers.dev/",
    },
  ];

  return (
    <section id="clients" className="py-20 md:py-28 bg-card/30">
      <div className="container mx-auto px-4">
        <SectionHeader
          eyebrow="أبرز العملاء"
          title={<>مشاريع <span className="text-gradient">أنجزناها بنجاح</span></>}
          subtitle="نفتخر بثقة عملائنا. إليك بعض المشاريع التي صممناها وأطلقناها."
        />
        <div className="mt-12 grid gap-6 sm:grid-cols-2 lg:grid-cols-2 max-w-4xl mx-auto">
          {projects.map((p) => (
            <a
              key={p.url}
              href={p.url}
              target="_blank"
              rel="noopener noreferrer"
              className="group glass-card rounded-2xl p-6 flex flex-col transition hover:border-neon-cyan/50 hover:-translate-y-1"
            >
              <div className="flex items-center justify-between mb-4">
                <div className="inline-flex items-center gap-2 rounded-full border border-neon-cyan/30 bg-neon-cyan/5 px-3 py-1 text-xs text-neon-cyan">
                  <p.icon className="size-3" />
                  {p.category}
                </div>
                <ExternalLink className="size-4 text-muted-foreground opacity-0 group-hover:opacity-100 transition" />
              </div>
              <h3 className="font-display text-xl font-bold">{p.name}</h3>
              <p className="text-sm text-muted-foreground mt-2 leading-relaxed flex-1">{p.desc}</p>
              <div className="mt-4 text-xs text-muted-foreground/60 truncate">{p.url.replace("https://", "")}</div>
            </a>
          ))}
        </div>
      </div>
    </section>
  );
}

/* =================== TECH =================== */
function Tech() {
  const techs = ["Shopify", "WordPress", "Next.js", "Tailwind", "HTML5", "CSS3"];
  return (
    <section className="py-16 border-y border-border bg-card/30">
      <div className="container mx-auto px-4">
        <p className="text-center text-xs uppercase tracking-widest text-muted-foreground mb-8">التقنيات التي نعمل بها</p>
        <div className="flex flex-wrap justify-center items-center gap-x-10 gap-y-4">
          {techs.map(t => (
            <span key={t} className="font-display text-xl md:text-2xl font-bold text-muted-foreground/70 hover:text-foreground transition">
              {t}
            </span>
          ))}
        </div>
      </div>
    </section>
  );
}

/* =================== REVIEWS =================== */
function Reviews() {
  const fn = useServerFn(getReviews);
  const submit = useServerFn(submitReview);
  const qc = useQueryClient();
  const { data } = useQuery({ queryKey: ["reviews"], queryFn: () => fn() });
  const m = useMutation({
    mutationFn: (input: { name: string; email: string; rating: number; comment: string }) =>
      submit({ data: input }),
    onSuccess: () => {
      toast.success("شكراً لمراجعتك! سيتم نشرها بعد المراجعة.");
      qc.invalidateQueries({ queryKey: ["reviews"] });
    },
    onError: (e: Error) => toast.error(e.message || "تعذّر إرسال المراجعة"),
  });

  const [form, setForm] = useState({ name: "", email: "", rating: 5, comment: "" });
  const avg = data && data.length ? (data.reduce((a, r) => a + r.rating, 0) / data.length).toFixed(1) : "5.0";

  return (
    <section className="py-20 md:py-28">
      <div className="container mx-auto px-4">
        <SectionHeader eyebrow="آراء العملاء" title={<>ماذا يقول <span className="text-gradient">عملاؤنا</span></>} />
        <div className="mt-6 flex items-center justify-center gap-2 text-sm">
          <div className="flex gap-0.5">
            {[1,2,3,4,5].map(i => <Star key={i} className="size-4 fill-neon-cyan text-neon-cyan" />)}
          </div>
          <span className="text-muted-foreground">{avg} / 5 · {data?.length ?? 0} مراجعة</span>
        </div>

        <div className="mt-12 grid gap-6 lg:grid-cols-[1.5fr_1fr]">
          <div className="grid gap-4 sm:grid-cols-2 content-start">
            {data?.map(r => (
              <div key={r.id} className="glass-card rounded-2xl p-6">
                <div className="flex items-center gap-3 mb-3">
                  <div className="grid place-items-center size-10 rounded-full bg-gradient-neon font-bold text-background">
                    {r.name.charAt(0)}
                  </div>
                  <div>
                    <div className="font-bold">{r.name}</div>
                    <div className="flex gap-0.5 mt-0.5">
                      {Array.from({ length: r.rating }).map((_, i) => (
                        <Star key={i} className="size-3 fill-neon-cyan text-neon-cyan" />
                      ))}
                    </div>
                  </div>
                </div>
                <p className="text-sm text-muted-foreground leading-relaxed">{r.comment}</p>
              </div>
            ))}
          </div>

          <form onSubmit={(e) => { e.preventDefault(); m.mutate(form); }}
            className="glass-card rounded-2xl p-6 space-y-4 self-start">
            <h3 className="font-display text-xl font-bold">اترك مراجعتك</h3>
            <div>
              <label className="text-sm mb-2 block">تقييمك</label>
              <div className="flex gap-1">
                {[1,2,3,4,5].map(i => (
                  <button key={i} type="button" onClick={() => setForm(f => ({ ...f, rating: i }))}>
                    <Star className={`size-7 transition ${i <= form.rating ? "fill-neon-cyan text-neon-cyan" : "text-muted-foreground"}`} />
                  </button>
                ))}
              </div>
            </div>
            <Input placeholder="الاسم" required value={form.name} onChange={e => setForm(f => ({ ...f, name: e.target.value }))} />
            <Input type="email" placeholder="البريد الإلكتروني (اختياري)" value={form.email} onChange={e => setForm(f => ({ ...f, email: e.target.value }))} />
            <Textarea placeholder="تعليقك" rows={4} required value={form.comment} onChange={e => setForm(f => ({ ...f, comment: e.target.value }))} />
            <Button type="submit" disabled={m.isPending} className="w-full bg-gradient-neon text-background font-bold hover:opacity-90">
              {m.isPending ? "جارٍ الإرسال..." : "إرسال المراجعة"}
            </Button>
          </form>
        </div>
      </div>
    </section>
  );
}

/* =================== FAQ =================== */
function FAQ() {
  const qs = [
    { q: "هل تسلّمون فعلاً خلال 24 ساعة؟", a: "نعم! بمجرد استلام تفاصيل مشروعك والمحتوى اللازم، نبدأ فوراً ونسلّم خلال 24 ساعة." },
    { q: "ماذا تشمل الخدمة؟", a: "التصميم، التطوير، إعداد النطاق، تحسين السرعة وSEO الأساسي، وأسبوع من التعديلات المجانية." },
    { q: "هل أحتاج لمهارات تقنية؟", a: "إطلاقاً. نحن نتولّى كل شيء، ونزوّدك بدليل بسيط لإدارة موقعك بنفسك لاحقاً." },
    { q: "هل يمكنني تعديل الموقع لاحقاً؟", a: "بالتأكيد. سنزوّدك بلوحة تحكم سهلة الاستخدام، وندعمك في أي تعديلات مستقبلية." },
    { q: "ماذا لو أردت تصميماً مخصصاً تماماً؟", a: "تواصل معنا وأخبرنا برؤيتك، ونقدّم لك عرضاً مخصصاً يناسب احتياجاتك." },
  ];
  return (
    <section id="faq" className="py-20 md:py-28 bg-card/30">
      <div className="container mx-auto px-4 max-w-3xl">
        <SectionHeader eyebrow="الأسئلة الشائعة" title={<>نجيب على <span className="text-gradient">استفساراتك</span></>} />
        <Accordion type="single" collapsible className="mt-10 space-y-3">
          {qs.map((q, i) => (
            <AccordionItem key={i} value={`q-${i}`} className="glass-card rounded-2xl border-0 px-5">
              <AccordionTrigger className="hover:no-underline py-5 font-bold text-start">{q.q}</AccordionTrigger>
              <AccordionContent className="text-muted-foreground pb-5 leading-relaxed">{q.a}</AccordionContent>
            </AccordionItem>
          ))}
        </Accordion>
      </div>
    </section>
  );
}

/* =================== CONTACT =================== */
function Contact() {
  const submit = useServerFn(submitLead);
  const m = useMutation({
    mutationFn: (input: { name: string; email: string; phone: string; idea: string }) =>
      submit({ data: input }),
    onSuccess: (_data, variables) => {
      toast.success("شكراً! سنتواصل معك خلال أقل من 24 ساعة.");
      const msg = `مرحباً، أنا ${variables.name}%0Aالبريد: ${variables.email}${variables.phone ? `%0Aالهاتف: ${variables.phone}` : ""}%0Aفكرتي: ${variables.idea}`;
      window.open(`https://wa.me/967771220344?text=${encodeURIComponent(msg)}`, "_blank");
      setForm({ name: "", email: "", phone: "", idea: "" });
    },
    onError: (e: Error) => toast.error(e.message || "تعذّر الإرسال"),
  });
  const [form, setForm] = useState({ name: "", email: "", phone: "", idea: "" });

  return (
    <section id="contact" className="py-20 md:py-28 relative">
      <div className="container mx-auto px-4">
        <div className="grid gap-12 lg:grid-cols-2 items-center">
          <div>
            <div className="inline-flex items-center gap-2 rounded-full border border-neon-cyan/40 bg-neon-cyan/5 px-4 py-1.5 text-xs text-neon-cyan mb-6">
              <Sparkles className="size-3.5" />
              تواصل مباشر
            </div>
            <h2 className="font-display text-4xl md:text-5xl font-extrabold leading-tight">
              مستعد لإطلاق موقعك <span className="text-gradient">غداً؟</span>
            </h2>
            <p className="mt-4 text-muted-foreground leading-relaxed">
              أخبرنا بفكرتك وسنرد عليك خلال أقل من 24 ساعة باقتراح مخصّص لك.
            </p>
            <a href="https://wa.me/967771220344" target="_blank" rel="noopener noreferrer" className="mt-6 inline-flex items-center gap-2 text-neon-cyan hover:underline">
              <Phone className="size-4" />
              +967 771 220 344
            </a>
            <ul className="mt-8 space-y-3 text-sm">
              {["بدون التزام", "رد سريع", "تسليم خلال 24 ساعة"].map(t => (
                <li key={t} className="flex items-center gap-2">
                  <Check className="size-4 text-neon-cyan" /> {t}
                </li>
              ))}
            </ul>
          </div>

          <form onSubmit={e => { e.preventDefault(); m.mutate(form); }} className="glass-card rounded-3xl p-8 space-y-4 glow-purple">
            <div className="relative">
              <User className="absolute right-3 top-1/2 -translate-y-1/2 size-4 text-muted-foreground" />
              <Input required placeholder="الاسم الكامل" className="pe-10" value={form.name} onChange={e => setForm(f => ({ ...f, name: e.target.value }))} />
            </div>
            <div className="relative">
              <Mail className="absolute right-3 top-1/2 -translate-y-1/2 size-4 text-muted-foreground" />
              <Input required type="email" placeholder="البريد الإلكتروني" className="pe-10" value={form.email} onChange={e => setForm(f => ({ ...f, email: e.target.value }))} />
            </div>
            <div className="relative">
              <Phone className="absolute right-3 top-1/2 -translate-y-1/2 size-4 text-muted-foreground" />
              <Input type="tel" placeholder="الهاتف (اختياري)" className="pe-10" value={form.phone} onChange={e => setForm(f => ({ ...f, phone: e.target.value }))} />
            </div>
            <Textarea required rows={5} placeholder="فكرة موقعك أو متجرك..." value={form.idea} onChange={e => setForm(f => ({ ...f, idea: e.target.value }))} />
            <Button type="submit" disabled={m.isPending} className="w-full bg-gradient-neon text-background font-bold py-6 text-base hover:opacity-90 glow-cyan">
              {m.isPending ? "جارٍ الإرسال..." : "ابدأ مشروعي الآن"}
            </Button>
            <p className="text-xs text-muted-foreground text-center">بياناتك تُستخدم فقط للتواصل بشأن مشروعك.</p>
          </form>
        </div>
      </div>
    </section>
  );
}

/* =================== FOOTER =================== */
function Footer() {
  return (
    <footer className="border-t border-border py-10 bg-card/30">
      <div className="container mx-auto px-4 flex flex-col md:flex-row items-center justify-between gap-4 text-sm text-muted-foreground">
        <div className="flex items-center gap-2 font-display font-bold">
          <span className="grid place-items-center size-7 rounded-lg bg-gradient-neon">
            <Zap className="size-3.5 text-background" strokeWidth={2.5} />
          </span>
          Websity<span className="text-gradient">-Yemen</span>
        </div>
        <p>© {new Date().getFullYear()} جميع الحقوق محفوظة.</p>
      </div>
    </footer>
  );
}

/* =================== COOKIE BANNER =================== */
function CookieBanner() {
  const [show, setShow] = useState(false);
  useEffect(() => {
    if (typeof window !== "undefined" && !localStorage.getItem("cookie-ok")) setShow(true);
  }, []);
  if (!show) return null;
  const close = () => { localStorage.setItem("cookie-ok", "1"); setShow(false); };
  return (
    <div className="fixed bottom-4 inset-x-4 md:inset-x-auto md:end-4 md:max-w-sm z-50 glass-card rounded-2xl p-5 shadow-2xl">
      <div className="flex items-center gap-2 font-bold mb-2">
        🍪 نستخدم ملفات تعريف الارتباط
      </div>
      <p className="text-sm text-muted-foreground mb-4">
        نستخدم ملفات الكوكيز التقنية لضمان عمل الموقع بشكل صحيح.
      </p>
      <div className="flex gap-2">
        <button onClick={close} className="flex-1 rounded-lg bg-gradient-neon py-2 text-sm font-bold text-background">قبول</button>
        <button onClick={close} className="flex-1 rounded-lg border border-border py-2 text-sm">رفض</button>
      </div>
    </div>
  );
}

/* =================== SECTION HEADER =================== */
function SectionHeader({ eyebrow, title, subtitle }: { eyebrow: string; title: React.ReactNode; subtitle?: string }) {
  return (
    <div className="text-center max-w-2xl mx-auto">
      <div className="text-xs uppercase tracking-widest text-neon-cyan font-bold">{eyebrow}</div>
      <h2 className="mt-3 font-display text-3xl md:text-5xl font-extrabold leading-tight">{title}</h2>
      {subtitle && <p className="mt-4 text-muted-foreground">{subtitle}</p>}
    </div>
  );
}
