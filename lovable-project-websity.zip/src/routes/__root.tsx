import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import {
  Outlet,
  Link,
  createRootRouteWithContext,
  useRouter,
  HeadContent,
  Scripts,
} from "@tanstack/react-router";
import { useEffect, type ReactNode } from "react";

import appCss from "../styles.css?url";
import { reportLovableError } from "../lib/lovable-error-reporting";
import { Toaster } from "@/components/ui/sonner";

function NotFoundComponent() {
  return (
    <div className="flex min-h-screen items-center justify-center bg-background px-4">
      <div className="max-w-md text-center">
        <h1 className="text-7xl font-bold text-gradient">404</h1>
        <h2 className="mt-4 text-xl font-semibold">الصفحة غير موجودة</h2>
        <p className="mt-2 text-sm text-muted-foreground">
          الصفحة التي تبحث عنها غير متوفرة أو تم نقلها.
        </p>
        <div className="mt-6">
          <Link
            to="/"
            className="inline-flex items-center justify-center rounded-md bg-gradient-neon px-5 py-2 text-sm font-bold text-background"
          >
            العودة للرئيسية
          </Link>
        </div>
      </div>
    </div>
  );
}

function ErrorComponent({ error, reset }: { error: Error; reset: () => void }) {
  console.error(error);
  const router = useRouter();
  useEffect(() => {
    reportLovableError(error, { boundary: "tanstack_root_error_component" });
  }, [error]);

  return (
    <div className="flex min-h-screen items-center justify-center bg-background px-4">
      <div className="max-w-md text-center">
        <h1 className="text-xl font-semibold">حدث خطأ غير متوقع</h1>
        <p className="mt-2 text-sm text-muted-foreground">
          واجهنا مشكلة أثناء تحميل الصفحة. يمكنك إعادة المحاولة أو الرجوع للرئيسية.
        </p>
        <div className="mt-6 flex flex-wrap justify-center gap-2">
          <button
            onClick={() => { router.invalidate(); reset(); }}
            className="rounded-md bg-gradient-neon px-4 py-2 text-sm font-bold text-background"
          >
            إعادة المحاولة
          </button>
          <a href="/" className="rounded-md border border-border px-4 py-2 text-sm">
            الرئيسية
          </a>
        </div>
      </div>
    </div>
  );
}

export const Route = createRootRouteWithContext<{ queryClient: QueryClient }>()({
  head: () => ({
    meta: [
      { charSet: "utf-8" },
      { name: "viewport", content: "width=device-width, initial-scale=1" },
      { title: "Websity-yemen — متجرك الإلكتروني جاهز خلال 24 ساعة" },
      { name: "description", content: "نصمم ونطوّر وننشر متجرك أو موقعك الاحترافي في 24 ساعة. تصميم بريميوم محسّن للبيع." },
      { property: "og:title", content: "Websity-yemen — متجرك الإلكتروني جاهز خلال 24 ساعة" },
      { property: "og:description", content: "نصمم ونطوّر وننشر متجرك أو موقعك الاحترافي في 24 ساعة. تصميم بريميوم محسّن للبيع." },
      { property: "og:type", content: "website" },
      { property: "og:site_name", content: "Websity-Yemen" },
      { name: "twitter:card", content: "summary_large_image" },
      { name: "twitter:title", content: "Websity-yemen — متجرك الإلكتروني جاهز خلال 24 ساعة" },
      { name: "twitter:description", content: "نصمم ونطوّر وننشر متجرك أو موقعك الاحترافي في 24 ساعة. تصميم بريميوم محسّن للبيع." },
      { property: "og:image", content: "https://storage.googleapis.com/gpt-engineer-file-uploads/MDph31FEAcS52UAsN52SwOid4Dr1/social-images/social-1780752331792-1000474549.webp" },
      { name: "twitter:image", content: "https://storage.googleapis.com/gpt-engineer-file-uploads/MDph31FEAcS52UAsN52SwOid4Dr1/social-images/social-1780752331792-1000474549.webp" },
    ],
    links: [
      { rel: "stylesheet", href: appCss },
      { rel: "preconnect", href: "https://fonts.googleapis.com" },
      { rel: "preconnect", href: "https://fonts.gstatic.com", crossOrigin: "anonymous" },
      {
        rel: "stylesheet",
        href: "https://fonts.googleapis.com/css2?family=Cairo:wght@400;600;700;800;900&family=Tajawal:wght@300;400;500;700&display=swap",
      },
    ],
  }),
  shellComponent: RootShell,
  component: RootComponent,
  notFoundComponent: NotFoundComponent,
  errorComponent: ErrorComponent,
});

function RootShell({ children }: { children: ReactNode }) {
  return (
    <html lang="ar" dir="rtl" className="dark">
      <head>
        <HeadContent />
      </head>
      <body>
        {children}
        <Scripts />
      </body>
    </html>
  );
}

function RootComponent() {
  const { queryClient } = Route.useRouteContext();

  return (
    <QueryClientProvider client={queryClient}>
      <Outlet />
      <Toaster position="top-center" richColors />
    </QueryClientProvider>
  );
}
